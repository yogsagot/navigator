"""The screen buffer and the views widgets paint through.

Widgets never write to the terminal.  They paint cells into a
:class:`Surface`, and once a frame is complete :func:`render_diff` compares
the finished :class:`ScreenBuffer` against the previously flushed one and
emits only the escape sequences needed to turn one into the other.

There are two kinds of surface.  :class:`ScreenBuffer` owns a grid of cells;
a *view* owns nothing and forwards to another surface, shifting coordinates
and clipping to a rectangle.  A widget is handed a view of its own area, so
it paints from ``0, 0`` in its own size and physically cannot draw outside
itself -- no widget needs to know where on the screen it ended up, and none
can scribble on its neighbours.
"""

from __future__ import annotations

import unicodedata
from typing import TYPE_CHECKING

from navkit import glyphs
from navkit.style import DEFAULT_STYLE, RESET_SGR, Style

if TYPE_CHECKING:
    # Only for the annotation: the renderer takes whatever it is handed, and
    # importing it for real would tie the buffer to the terminal layer.
    from navkit.capabilities import TerminalInfo

#: A painted cell: the character it shows and the style it shows it in.  The
#: character is ``""`` for the second half of a double-width character, which
#: the owning cell already emitted.
type Cell = tuple[str, Style]

#: Re-exported so that a caller already holding a ``Surface`` need not reach
#: for another module to name the commonest two.  They live in
#: :mod:`navkit.glyphs` with the rest of the vocabulary, because deciding
#: *which* set to draw is a question about the terminal and this module is
#: deliberately innocent of those.
SINGLE_BOX = glyphs.SINGLE_BOX
DOUBLE_BOX = glyphs.DOUBLE_BOX


def char_width(char: str) -> int:
    """Return how many terminal cells *char* occupies (0, 1 or 2)."""
    if not char:
        return 0
    code = ord(char)
    if code < 0x20 or 0x7F <= code < 0xA0:
        return 0
    if code < 0x7F:
        # Printable ASCII is always one cell and never combining.  Worth
        # saying so: this runs for every character of every frame, and the
        # unicodedata lookups below are far from free.
        return 1
    if unicodedata.combining(char):
        return 0
    # The Private Use Area reports "A" here and so measures one cell, which is
    # what a Nerd Font *Mono* build patches its icons to.  The plain build
    # draws some of them two cells wide and there is no table that would say
    # so, which is why a widget reserves the second cell rather than trusting
    # this -- see ``Panel``'s icon gutter.
    return 2 if unicodedata.east_asian_width(char) in ("W", "F") else 1


def _blit_bounds(
    target: Surface,
    source: Surface,
    x: int,
    y: int,
    src_x: int,
    src_y: int,
    width: int | None,
    height: int | None,
) -> tuple[int, int, int, int]:
    """The source-relative rectangle a blit actually has to walk.

    Clipped against both surfaces at once, so neither the loop nor the row
    copy below it ever visits a cell that one of the two would throw away.
    """
    span = (source.width - src_x) if width is None else width
    rows = (source.height - src_y) if height is None else height
    left = max(0, -x, -src_x)
    top = max(0, -y, -src_y)
    right = min(span, target.width - x, source.width - src_x)
    bottom = min(rows, target.height - y, source.height - src_y)
    return left, top, max(left, right), max(top, bottom)


class Surface:
    """Somewhere a widget can paint, in its own coordinates.

    Subclasses provide :meth:`get`, :meth:`set_cell` and :meth:`fill`; the
    rest is written in terms of those, so it works the same whether the cells
    are really there or the calls are being forwarded to a parent.

    All drawing clips silently against ``width`` x ``height``, so a widget may
    paint at negative or oversized coordinates without checking first.
    """

    __slots__ = ()

    #: The area available, starting at ``0, 0``.
    width: int
    height: int

    def get(self, x: int, y: int) -> Cell:
        """Return the cell at *x*, *y*, or a blank cell if out of bounds."""
        raise NotImplementedError

    def set_cell(self, x: int, y: int, char: str, style: Style = DEFAULT_STYLE) -> int:
        """Paint a single character and return how many cells it consumed."""
        raise NotImplementedError

    def fill(
        self,
        x: int,
        y: int,
        width: int,
        height: int,
        char: str = " ",
        style: Style = DEFAULT_STYLE,
    ) -> None:
        """Fill a rectangle with *char*."""
        raise NotImplementedError

    def view(self, x: int, y: int, width: int, height: int) -> Surface:
        """A surface onto the *width* x *height* area at *x*, *y*.

        Painting through it is offset by *x*, *y* and clipped to the
        rectangle, so what the caller sees is a surface of its own.  Views
        nest: taking a view of a view intersects the two clips.
        """
        return _View(self, x, y, width, height)

    def blit(
        self,
        source: Surface,
        x: int = 0,
        y: int = 0,
        src_x: int = 0,
        src_y: int = 0,
        width: int | None = None,
        height: int | None = None,
    ) -> None:
        """Copy a rectangle of cells out of *source* and into *x*, *y* here.

        The generic implementation, written in terms of :meth:`get` and
        :meth:`set_cell` so any surface has it; :class:`ScreenBuffer` and
        :class:`_View` override it with something that moves whole rows.

        Both edges of a copy can fall in the middle of a double-width
        character.  A cell whose owner was clipped away, and a wide character
        whose trailing half was, both become a blank -- the same bargain
        :meth:`ScreenBuffer.set_cell` makes at the edge of the screen.
        """
        left, top, right, bottom = _blit_bounds(
            self, source, x, y, src_x, src_y, width, height
        )
        for row in range(top, bottom):
            for col in range(left, right):
                char, style = source.get(src_x + col, src_y + row)
                if char == "":
                    # The trailing half of a wide character.  Its owner
                    # painted both cells, unless the owner is the cell we just
                    # clipped off the left edge -- then there is nothing to
                    # show but a blank.
                    if col == left:
                        self.set_cell(x + col, y + row, " ", style)
                    continue
                if char_width(char) == 2 and col + 1 >= right:
                    self.set_cell(x + col, y + row, " ", style)
                    continue
                self.set_cell(x + col, y + row, char, style)

    def draw_text(
        self,
        x: int,
        y: int,
        text: str,
        style: Style = DEFAULT_STYLE,
        max_width: int | None = None,
    ) -> int:
        """Paint *text* starting at *x*, *y*; return the cells consumed."""
        limit = self.width - x if max_width is None else min(max_width, self.width - x)
        used = 0
        for char in text:
            width = char_width(char)
            if width == 0:
                continue
            if used + width > limit:
                break
            self.set_cell(x + used, y, char, style)
            used += width
        return used

    def draw_box(
        self,
        x: int,
        y: int,
        width: int,
        height: int,
        style: Style = DEFAULT_STYLE,
        *,
        charset: str = SINGLE_BOX,
        fill: str | None = None,
    ) -> None:
        """Draw a box frame, optionally filling its interior with *fill*.

        *charset* is the six characters themselves -- top-left, top-right,
        bottom-left, bottom-right, horizontal, vertical -- and not a name for
        them.  Which set a widget asks for is a question about the stylesheet
        and the terminal's font, and both are answered before this is called;
        see :func:`navkit.glyphs.charset`.
        """
        if width < 2 or height < 2:
            return
        tl, tr, bl, br, horizontal, vertical = charset
        right = x + width - 1
        bottom = y + height - 1
        if fill is not None:
            self.fill(x + 1, y + 1, width - 2, height - 2, fill, style)
        for col in range(x + 1, right):
            self.set_cell(col, y, horizontal, style)
            self.set_cell(col, bottom, horizontal, style)
        for row in range(y + 1, bottom):
            self.set_cell(x, row, vertical, style)
            self.set_cell(right, row, vertical, style)
        self.set_cell(x, y, tl, style)
        self.set_cell(right, y, tr, style)
        self.set_cell(x, bottom, bl, style)
        self.set_cell(right, bottom, br, style)


class _View(Surface):
    """A shifted, clipped window onto another surface.

    It holds no cells of its own, so handing one to every widget on every
    frame costs an object and nothing else -- there is no second copy of the
    screen to composite afterwards.
    """

    __slots__ = ("_target", "_x", "_y", "width", "height")

    def __init__(self, target: Surface, x: int, y: int, width: int, height: int):
        self._target = target
        self._x = x
        self._y = y
        # The declared size, not what survives clipping against the target: a
        # widget hanging off the edge of the screen should still lay its own
        # contents out as though it were whole.
        self.width = max(0, width)
        self.height = max(0, height)

    def get(self, x: int, y: int) -> Cell:
        if not (0 <= x < self.width and 0 <= y < self.height):
            return (" ", DEFAULT_STYLE)
        return self._target.get(self._x + x, self._y + y)

    def set_cell(self, x: int, y: int, char: str, style: Style = DEFAULT_STYLE) -> int:
        if not (0 <= x < self.width and 0 <= y < self.height):
            return max(1, char_width(char))
        if char_width(char) == 2 and x + 1 >= self.width:
            # The trailing half would land on whatever is beside this widget,
            # so show a blank rather than let it escape -- the same bargain
            # ScreenBuffer makes at the edge of the screen.
            self._target.set_cell(self._x + x, self._y + y, " ", style)
            return 2
        return self._target.set_cell(self._x + x, self._y + y, char, style)

    def fill(
        self,
        x: int,
        y: int,
        width: int,
        height: int,
        char: str = " ",
        style: Style = DEFAULT_STYLE,
    ) -> None:
        left, top = max(0, x), max(0, y)
        right, bottom = min(self.width, x + width), min(self.height, y + height)
        if right > left and bottom > top:
            self._target.fill(
                self._x + left, self._y + top, right - left, bottom - top, char, style
            )

    def blit(
        self,
        source: Surface,
        x: int = 0,
        y: int = 0,
        src_x: int = 0,
        src_y: int = 0,
        width: int | None = None,
        height: int | None = None,
    ) -> None:
        # Clip here, then hand the whole rectangle to the target in one call.
        # Forwarding rather than looping is what lets a widget -- which only
        # ever sees a view -- reach ScreenBuffer's row copy underneath.
        left, top, right, bottom = _blit_bounds(
            self, source, x, y, src_x, src_y, width, height
        )
        if right <= left or bottom <= top:
            return
        self._target.blit(
            source,
            self._x + x + left,
            self._y + y + top,
            src_x + left,
            src_y + top,
            right - left,
            bottom - top,
        )


class ScreenBuffer(Surface):
    """A grid of cells: the surface a whole frame is composed in."""

    __slots__ = ("width", "height", "_rows")

    def __init__(self, width: int, height: int, style: Style = DEFAULT_STYLE):
        self.width = max(0, width)
        self.height = max(0, height)
        self._rows: list[list[Cell]] = []
        self.clear(style)

    def resize(self, width: int, height: int, style: Style = DEFAULT_STYLE) -> None:
        """Resize the buffer, discarding its contents."""
        self.width = max(0, width)
        self.height = max(0, height)
        self.clear(style)

    def clear(self, style: Style = DEFAULT_STYLE, char: str = " ") -> None:
        """Fill the whole buffer with *char* in *style*."""
        blank: Cell = (char, style)
        self._rows = [[blank] * self.width for _ in range(self.height)]

    def get(self, x: int, y: int) -> Cell:
        """Return the cell at *x*, *y*, or a blank cell if out of bounds."""
        if 0 <= y < self.height and 0 <= x < self.width:
            return self._rows[y][x]
        return (" ", DEFAULT_STYLE)

    def set_cell(self, x: int, y: int, char: str, style: Style = DEFAULT_STYLE) -> int:
        """Paint a single character and return how many cells it consumed."""
        if not (0 <= y < self.height) or not (0 <= x < self.width):
            return max(1, char_width(char))
        width = char_width(char)
        if width == 0:
            return 0
        row = self._rows[y]
        row[x] = (char, style)
        if width == 2:
            if x + 1 < self.width:
                row[x + 1] = ("", style)
            else:
                # No room for the trailing half -- show a blank instead of
                # letting the terminal wrap it onto the next line.
                row[x] = (" ", style)
        return width

    def fill(
        self,
        x: int,
        y: int,
        width: int,
        height: int,
        char: str = " ",
        style: Style = DEFAULT_STYLE,
    ) -> None:
        """Fill a rectangle with *char*."""
        cell: Cell = (char, style)
        left, right = max(0, x), min(self.width, x + width)
        if right <= left:
            return
        span = [cell] * (right - left)
        for row in range(max(0, y), min(self.height, y + height)):
            self._rows[row][left:right] = span

    def blit(
        self,
        source: Surface,
        x: int = 0,
        y: int = 0,
        src_x: int = 0,
        src_y: int = 0,
        width: int | None = None,
        height: int | None = None,
    ) -> None:
        if not isinstance(source, ScreenBuffer):
            super().blit(source, x, y, src_x, src_y, width, height)
            return
        left, top, right, bottom = _blit_bounds(
            self, source, x, y, src_x, src_y, width, height
        )
        if right <= left or bottom <= top:
            return
        # Both grids hold cells in the same representation, so a row is a
        # slice assignment -- one list copy in C rather than a Python call per
        # cell.  This is the path a console screen full of output takes every
        # frame, which is the whole reason for the override.
        for row in range(top, bottom):
            span = source._rows[src_y + row][src_x + left : src_x + right]
            if span[0][0] == "":
                # Its owner was clipped off the left edge.
                span[0] = (" ", span[0][1])
            if char_width(span[-1][0]) == 2:
                # Its trailing half was clipped off the right edge.
                span[-1] = (" ", span[-1][1])
            self._rows[y + row][x + left : x + right] = span

    def copy_from(self, other: ScreenBuffer) -> None:
        """Make this buffer an independent copy of *other*."""
        self.width = other.width
        self.height = other.height
        self._rows = [row.copy() for row in other._rows]


def render_diff(
    previous: ScreenBuffer | None,
    current: ScreenBuffer,
    info: TerminalInfo | None = None,
) -> str:
    """Return the escape sequences turning *previous* into *current*.

    Passing ``None`` -- or a buffer of a different size, as happens right after
    a resize -- forces a full repaint.

    *info* is where a colour the terminal cannot name is quantised to one it
    can: this is the last place a :class:`~navkit.style.Style` exists before it
    becomes bytes, so it is the only place that decision belongs.  ``None``
    means emit what the styles say, which is what a caller rendering to a
    string rather than to a tty wants.

    Most frames change a handful of rows, so each row is first compared whole:
    one list comparison in C rules out a row that nobody touched, and only the
    survivors are walked cell by cell.  On a large terminal that is the
    difference between the diff costing more than the render and costing
    almost nothing.
    """
    full = (
        previous is None
        or previous.width != current.width
        or previous.height != current.height
    )
    out: list[str] = []
    if full:
        out.append(RESET_SGR + "\x1b[H\x1b[2J")

    style: Style | None = None
    cursor: tuple[int, int] | None = None

    for y in range(current.height):
        if not full and previous is not None and previous._rows[y] == current._rows[y]:
            # Nothing on this row moved.  Skipping it is safe: emitting
            # nothing leaves the terminal's cursor and pending SGR exactly
            # where the rows above left them.
            continue
        x = 0
        while x < current.width:
            cell = current.get(x, y)
            char, cell_style = cell
            if char == "":
                # Trailing half of a wide character; its owner emitted it.
                x += 1
                continue
            width = max(1, char_width(char))
            if not full and previous is not None and previous.get(x, y) == cell:
                x += width
                continue
            if cursor != (x, y):
                out.append(f"\x1b[{y + 1};{x + 1}H")
            if cell_style != style:
                out.append(info.sgr(cell_style) if info else cell_style.sgr())
                style = cell_style
            out.append(char)
            cursor = (x + width, y)
            x += width

    if out:
        out.append(RESET_SGR)
    return "".join(out)