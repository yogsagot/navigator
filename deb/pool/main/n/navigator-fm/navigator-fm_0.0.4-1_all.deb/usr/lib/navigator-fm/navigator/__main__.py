#!/usr/bin/env python3
"""Navigator -- a recreation of DOS Navigator for POSIX terminals.

The application entry point: ``python -m navigator``.  For now it is a thin
shell over navkit -- a menu bar, two directory panels and the function key
bar, drawn by hand.  As navml grows, these screens move into ``*.nml`` markup
and this module keeps only the event handlers.
"""

from __future__ import annotations

import argparse
import os
import sys
from dataclasses import replace
from importlib import metadata
from importlib.resources import files
from pathlib import Path

from navkit.application import Application
from navkit.capabilities import VGA_PALETTE, TerminalInfo
from navkit.console import ConsoleScreen, seed_from_host
from navkit.events import KeyEvent, MouseEvent
from navkit.process import PtyProcess
from navkit.reactive import bind, computed, effect, peek, reactive
from navkit.glyphs import GLYPHS_NERD, tier_named
from navkit.screen import Surface
from navkit.style import Style
from navkit.stylesheet import Stylesheet, parse_value, read, register_property
from navkit.terminal import Terminal, encode_key, is_a_tty
from navkit.widget import Widget

from navigator import __version__, icons

#: ``border`` is not a field of ``Style`` -- a box-drawing character set is an
#: input to a drawing operation, not an appearance a cell can carry -- so the
#: widget that reads it has to declare it before a sheet may name it.
register_property("border")

#: ``icons`` says whether a listing shows a Nerd Font glyph beside each
#: name.  ``auto`` -- the default -- means "whenever the terminal can draw
#: one", and ``none`` refuses even then, which is what a sheet aiming at
#: strict DOS fidelity sets.
register_property("icons")

#: Where sheets live.  A directory rather than a single file because a theme is
#: nothing more than another ``.nss`` loaded after the default one, so this is
#: also where one would be dropped.
#:
#: Located through the package rather than by walking out from ``__file__``,
#: so it resolves the same from a source checkout, from an installed copy, and
#: whether this module is run as ``__main__`` or imported by name.
STYLES = Path(str(files("navigator.styles")))

#: What the screens are made of: the rules, in terms of variables it does not
#: define.  It does not parse on its own; a palette always follows it.
SCHEME_PATH = STYLES / "navigator.nss"

#: The palettes, one per colour scheme, each defining every variable the sheet
#: above reads.  They are DOS Navigator's own ``COLORS/*.PAL`` files decoded by
#: ``tools/palconv.py``, so retheming is picking one rather than writing one.
THEMES = STYLES / "themes"

#: The scheme DOS Navigator itself starts in -- ``DEFAULT.PAL``.
DEFAULT_THEME = "default"


def theme_names() -> list[str]:
    """Every theme that can be asked for by name."""
    return sorted(path.stem for path in THEMES.glob("*.nss"))


def load_scheme(theme: str = DEFAULT_THEME, *extra) -> Stylesheet:
    """The rules, with *theme*'s palette merged over them.

    Merged rather than concatenated: the palette is only variable definitions,
    and those resolve across sheets before any rule is read, so a palette needs
    no rules of its own and cannot accidentally out-specify one.

    *extra* is anything :func:`~navkit.stylesheet.read` accepts, loaded last --
    a path to a sheet of one's own, or a ``(name, text)`` pair.
    """
    path = THEMES / f"{theme}.nss"
    if not path.is_file():
        raise LookupError(
            f"no theme {theme!r}; there is " + ", ".join(theme_names())
        )
    return read(SCHEME_PATH, path, *extra)


def desktop_style(scheme: Stylesheet) -> Style:
    """What the buffer is cleared to before the tree paints over it.

    Read out of the scheme's variables rather than resolved against a widget,
    because :class:`~navkit.application.Application` clears the screen before
    any widget exists to ask.
    """
    variables = scheme.variables
    return Style(
        fg=parse_value("fg", variables.get("desktop-fg", "default"), variables),
        bg=parse_value("bg", variables.get("desktop-bg", "default"), variables),
    )


#: Parsed once, because a sheet is immutable and every desktop that does not
#: ask for a theme resolves against the same one.
SCHEME = load_scheme()

MENU_ITEMS = ["Left", "Files", "Commands", "Options", "Right"]
FUNCTION_KEYS = [
    "Help",
    "Menu",
    "View",
    "Edit",
    "Copy",
    "RenMov",
    "Mkdir",
    "Delete",
    "PullDn",
    "Quit",
]


class DirEntry:
    """One line in a panel: a name, whether it is a directory, and its size."""

    __slots__ = ("name", "is_dir", "size")

    def __init__(self, name: str, is_dir: bool, size: int):
        self.name = name
        self.is_dir = is_dir
        self.size = size

    @property
    def sort_key(self) -> tuple:
        # ".." first, then directories, then files -- as in the original.
        return (self.name != "..", not self.is_dir, self.name.lower())

    @property
    def display_size(self) -> str:
        if self.name == "..":
            return " UP--DIR"
        if self.is_dir:
            return "     DIR"
        size = float(self.size)
        for unit in ("", "K", "M", "G", "T"):
            if size < 1024 or unit == "T":
                return f"{self.size:>8}" if not unit else f"{size:>7.0f}{unit}"
            size /= 1024
        return f"{self.size:>8}"


class Panel(Widget):
    """A file listing panel with a frame, a header and a cursor.

    The model is declarative: ``path`` is the only thing a command really
    assigns, and the listing, the cursor and the scroll offset follow it.  So
    the invariants -- the cursor sits on a row that exists, the scroll keeps
    it visible -- hold no matter which path changed the state, including a
    terminal resize, which the old imperative version got wrong.
    """

    path: Path = reactive(Path("."))
    entries: list[DirEntry] = reactive(factory=list)
    error: str | None = reactive(None)
    cursor: int = reactive(0)
    scroll: int = reactive(0)
    active: bool = reactive(False)
    #: Bumped to re-read a directory whose path has not changed.
    reload_token: int = reactive(0)

    def __init__(self, path: Path, **kwargs):
        super().__init__(**kwargs)
        #: Set by :meth:`enter` for the rescan that is about to happen, so the
        #: cursor can land on the directory we just climbed out of.
        self._return_to: str | None = None
        self.path = path
        # Declaration order is flush order: rebuild the listing, put the
        # cursor somewhere real, then scroll to it.
        effect(self, Panel._rescan)
        effect(self, Panel._clamp_cursor)
        effect(self, Panel._follow_cursor)

    # -- model ---------------------------------------------------------------

    def _rescan(self) -> None:
        """Re-read the directory, whenever the path or the token changes."""
        _ = self.reload_token  # read for the dependency; this is what Ctrl+R moves
        path = self.path
        entries: list[DirEntry] = []
        error: str | None = None
        if path != path.parent:
            entries.append(DirEntry("..", True, 0))
        try:
            with os.scandir(path) as scan:
                for item in scan:
                    try:
                        is_dir = item.is_dir()
                        size = 0 if is_dir else item.stat().st_size
                    except OSError:
                        is_dir, size = False, 0
                    entries.append(DirEntry(item.name, is_dir, size))
        except OSError as exc:
            error = exc.strerror or str(exc)
        entries.sort(key=lambda entry: entry.sort_key)

        self.entries = entries
        self.error = error
        target, self._return_to = self._return_to, None
        self.cursor = next(
            (index for index, item in enumerate(entries) if item.name == target), 0
        )
        self.scroll = 0

    def _clamp_cursor(self) -> None:
        """Keep the cursor on a row that exists, however the listing changed.

        Assigning what it also reads is allowed here: an effect's own writes
        are part of the run it is in and do not wake it again.
        """
        last = len(self.entries) - 1
        self.cursor = min(max(self.cursor, 0), last) if last >= 0 else 0

    def _follow_cursor(self) -> None:
        """Scroll just far enough to keep the cursor on screen.

        ``scroll`` is read with :func:`~navkit.reactive.peek` because this is
        the effect that assigns it; subscribing to it would be a loop.
        """
        cursor, rows = self.cursor, self.rows
        scroll = peek(self, Panel.scroll)
        if cursor < scroll:
            self.scroll = cursor
        elif cursor >= scroll + rows:
            self.scroll = cursor - rows + 1

    def reload(self) -> None:
        """Re-read the directory this panel shows."""
        self.reload_token += 1

    @computed
    def rows(self) -> int:
        """How many listing lines fit between the top and bottom frame."""
        return max(0, self.height - 2)

    @computed
    def selected(self) -> DirEntry | None:
        """The entry the cursor is on, if the listing has one."""
        if 0 <= self.cursor < len(self.entries):
            return self.entries[self.cursor]
        return None

    def move_cursor(self, delta: int) -> None:
        if not self.entries:
            return
        # Deliberately unclamped: _clamp_cursor owns that invariant.
        self.cursor += delta

    def enter(self) -> None:
        """Descend into the selected directory."""
        entry = self.selected
        if entry is None or not entry.is_dir:
            return
        # The rescan is deferred, so the cursor we want afterwards has to be
        # left behind as a note rather than applied on the next line.
        self._return_to = self.path.name if entry.name == ".." else None
        self.path = (self.path / entry.name).resolve()

    # -- painting ------------------------------------------------------------

    @computed
    def title_text(self) -> str:
        """The path across the top frame, clipped to fit."""
        title = str(self.path)
        room = max(1, self.width - 4)
        if len(title) > room:
            title = "..." + title[-(room - 3) :]
        return f" {title} "

    @computed
    def footer_text(self) -> str:
        """The selected name, or an item count when there is nothing to name."""
        entry = self.selected
        summary = f" {entry.name} " if entry else f" {len(self.entries)} items "
        room = max(1, self.width - 4)
        return summary[: room - 1] + " " if len(summary) > room else summary

    @property
    def show_icons(self) -> bool:
        """Whether to reserve the icon gutter.

        Both halves have to agree, the way a terminal's mouse support and the
        caller's wish for it do: the sheet says whether icons are wanted and
        the terminal says whether its font could draw one.
        """
        return self.style_property("icons", "auto") != "none" and self.glyphs >= GLYPHS_NERD

    @property
    def gutter(self) -> int:
        """Columns held back at the left of a row for the icon.

        Two, not one.  A Nerd Font *Mono* build patches its icons to a single
        cell but the plain build does not, and no width table records which is
        installed; spending the second cell on a space means a glyph that comes
        out double-width covers it instead of shoving the name along.
        """
        return 2 if self.show_icons else 0

    @computed
    def name_width(self) -> int:
        """How much of a listing line is left once the size column is taken."""
        return max(1, self.width - 12)

    def render(self, surface: Surface) -> None:
        surface.draw_box(
            0,
            0,
            self.width,
            self.height,
            self.style,
            charset=self.box_charset(),
            fill=" ",
        )
        self._render_title(surface)
        self._render_entries(surface)
        self._render_footer(surface)

    def _render_title(self, surface: Surface) -> None:
        label = self.title_text
        style = self.part_style("title")
        surface.draw_text(max(1, (self.width - len(label)) // 2), 0, label, style)

    def _render_entries(self, surface: Surface) -> None:
        if self.error is not None:
            surface.draw_text(2, 2, self.error, self.part_style("error"), self.width - 4)
            return
        # Still an explicit limit: the name stops where the size column
        # begins, which is nearer than the edge the surface would clip at.
        gutter = self.gutter
        name_width = max(1, self.name_width - gutter)
        for row in range(self.rows):
            index = self.scroll + row
            if index >= len(self.entries):
                break
            entry = self.entries[index]
            # The cursor only shows on the panel that has focus, so the two
            # conditions are ANDed here rather than left to a ``:active``
            # selector: the row fill below is gated on the same answer.
            selected = index == self.cursor and self.active
            style = self.part_style(
                "row",
                classes=("directory",) if entry.is_dir else (),
                selected=selected,
            )
            y = 1 + row
            if selected:
                surface.fill(1, y, self.width - 2, 1, " ", style)
            if gutter:
                surface.draw_text(1, y, icons.icon_for(entry.name, entry.is_dir), style, gutter)
            surface.draw_text(1 + gutter, y, entry.name, style, name_width)
            surface.draw_text(self.width - 9, y, entry.display_size, style, 8)

    def _render_footer(self, surface: Surface) -> None:
        summary = self.footer_text
        surface.draw_text(
            max(1, (self.width - len(summary)) // 2),
            self.height - 1,
            summary,
            self.part_style("footer"),
        )


class MenuBar(Widget):
    """The pull-down menu bar across the top of the screen."""

    def render(self, surface: Surface) -> None:
        label, hotkey = self.style, self.part_style("hotkey")
        surface.fill(0, 0, self.width, 1, " ", label)
        column = 1
        for item in MENU_ITEMS:
            surface.draw_text(column, 0, item[0], hotkey)
            surface.draw_text(column + 1, 0, item[1:], label)
            column += len(item) + 2


class KeyBar(Widget):
    """The F1..F10 hint bar across the bottom of the screen."""

    def render(self, surface: Surface) -> None:
        label_style, number_style = self.style, self.part_style("number")
        surface.fill(0, 0, self.width, 1, " ", label_style)
        slot = max(3, self.width // len(FUNCTION_KEYS))
        for index, label in enumerate(FUNCTION_KEYS):
            column = index * slot
            if column >= self.width:
                break
            number = str(index + 1)
            surface.draw_text(column, 0, number, number_style)
            surface.draw_text(
                column + len(number),
                0,
                label.ljust(slot - len(number)),
                label_style,
                slot - len(number),
            )


class Console(Widget):
    """The screen a program Navigator started paints on.

    This is what Ctrl+O reveals.  DOS Navigator could show the last command's
    output behind its panels because in DOS there was one screen and the
    output was still in it; a terminal will not give its cells back, so the
    only way to have them is to have received them.  A shell runs on a pty
    this widget owns, its output goes through
    :class:`~navkit.console.ConsoleScreen`, and what arrives is a grid of
    cells like any other -- which is why the menu bar and the key bar can
    stay painted over it, and why it can be scrolled back through.
    """

    #: Bumped whenever the child writes, so the reactive layer knows the cells
    #: moved.  The screen behind it is not observable -- it is a great deal of
    #: mutable state that changes together -- so one counter stands for it.
    revision: int = reactive(0)

    def __init__(self, cwd: Path | None = None, **kwargs):
        super().__init__(**kwargs)
        self.cwd = cwd
        self.screen = ConsoleScreen(80, 24)
        self.process: PtyProcess | None = None
        self.seeded = False
        # The pty is told how big it is whenever this widget is, which is the
        # whole of the resize handling: the kernel raises SIGWINCH on the
        # child itself once the size is set.
        effect(self, Console._follow_size)

    def _follow_size(self) -> None:
        columns, lines = max(1, self.width), max(1, self.height)
        self.screen.resize(columns, lines)
        if self.process is not None:
            self.process.set_size(columns, lines)

    # -- the child -----------------------------------------------------------

    def start(self, argv: list[str] | None = None) -> None:
        """Start a program on the console, replacing any already running."""
        if self.process is not None and self.process.is_running:
            return
        if not self.seeded:
            # Whatever was on the real screen before Navigator ran, if this
            # host happens to keep it.  Once only, and before the shell's
            # first prompt lands on top of it.
            self.seeded = True
            seed_from_host(self.screen)
        shell = argv or [os.environ.get("SHELL") or "/bin/sh"]
        self.process = PtyProcess(
            shell,
            cwd=self.cwd,
            columns=max(1, self.width),
            lines=max(1, self.height),
            on_output=self._on_output,
            on_exit=self._on_exit,
        )
        try:
            self.process.start()
        except OSError:
            self.process = None

    def stop(self) -> None:
        if self.process is not None:
            self.process.terminate()
            self.process.close()
            self.process = None

    def _on_output(self, data: bytes) -> None:
        self.screen.feed(data)
        self.revision += 1

    def _on_exit(self, status: int) -> None:
        self.process = None
        self.revision += 1

    # -- input ---------------------------------------------------------------

    def send(self, event: KeyEvent) -> bool:
        """Type *event* at the child; ``False`` if there is nobody to type at."""
        if self.process is None or not self.process.is_running:
            return False
        data = encode_key(event)
        if not data:
            return False
        self.process.write(data)
        return True

    def scroll_back(self) -> None:
        self.screen.prev_page()
        self.revision += 1

    def scroll_forward(self) -> None:
        self.screen.next_page()
        self.revision += 1

    # -- painting ------------------------------------------------------------

    def render(self, surface: Surface) -> None:
        _ = self.revision  # read for the dependency: this is what output moves
        surface.fill(0, 0, self.width, self.height, " ", self.style)
        self.screen.blit_into(surface)
        column, row, hidden = self.screen.cursor
        if not hidden and 0 <= column < self.width and 0 <= row < self.height:
            char, style = surface.get(column, row)
            surface.set_cell(column, row, char or " ", style.derive(reverse=True))


class Manager(Widget):
    """The Navigator desktop: menu bar, two panels and the key bar."""

    #: Whether Ctrl+O has swapped the panels for the console.  Reactive, so
    #: the three widgets that care bind to it and nothing has to be repainted
    #: by hand.
    console_visible: bool = reactive(False)

    def __init__(self, left: Path, right: Path, scheme: Stylesheet = SCHEME):
        super().__init__()
        # The desktop brings its own look, so the tree is styled with or
        # without an application around it -- which is also what lets a single
        # panel be built and painted on its own.
        self._stylesheet = scheme
        self.menu = MenuBar()
        self.left = Panel(left)
        self.right = Panel(right)
        self.console = Console(left)
        self.keybar = KeyBar()
        for child in (self.menu, self.left, self.right, self.console, self.keybar):
            self.add(child)
        self._place()
        self.left.active = True

    def toggle_console(self) -> None:
        """Show or hide the console, starting its shell the first time."""
        showing = not self.console_visible
        if showing:
            self.console.start()
        self.console_visible = showing

    def _place(self) -> None:
        """Say how the desktop is divided, once, in terms of its own size.

        There is no ``layout`` method to go with this: every size that depends
        on the terminal is an expression, so a resize propagates by itself.
        This is the shape a ``*.nml`` file will compile to.
        """
        self.menu.x, self.menu.y = 0, 0
        self.menu.width = bind(lambda w: w.parent.width)
        self.menu.height = bind(lambda w: 1)

        self.keybar.x = 0
        self.keybar.y = bind(lambda w: max(1, w.parent.height - 1))
        self.keybar.width = bind(lambda w: w.parent.width)
        self.keybar.height = bind(lambda w: 1)

        self.left.x, self.left.y = 0, 1
        self.left.width = bind(lambda w: w.parent.width // 2)
        self.left.height = bind(lambda w: max(3, w.parent.height - 2))

        self.right.y = 1
        self.right.x = bind(lambda w: w.parent.width // 2)
        self.right.width = bind(lambda w: w.parent.width - w.parent.width // 2)
        self.right.height = bind(lambda w: max(3, w.parent.height - 2))

        # The console covers the band the two panels share, and the three of
        # them take turns.  This is the whole of Ctrl+O: `visible' is
        # reactive, so flipping the flag repaints without a layout pass, and
        # the menu bar and key bar are simply left alone -- which is why they
        # stay drawn over the output, as they were in DOS Navigator.
        self.console.x, self.console.y = 0, 1
        self.console.width = bind(lambda w: w.parent.width)
        self.console.height = bind(lambda w: max(1, w.parent.height - 2))
        self.console.visible = bind(lambda w: w.parent.console_visible)
        self.left.visible = bind(lambda w: not w.parent.console_visible)
        self.right.visible = bind(lambda w: not w.parent.console_visible)

    @computed
    def active_panel(self) -> Panel:
        """Whichever panel currently has the cursor."""
        return self.left if self.left.active else self.right

    def switch_panel(self) -> None:
        self.left.active, self.right.active = self.right.active, self.left.active

    def render(self, surface: Surface) -> None:
        surface.fill(0, 0, self.width, self.height, " ", self.style)


class Navigator(Application):
    """The file manager application."""

    def __init__(self, left: Path, right: Path, scheme: Stylesheet = SCHEME, **kwargs):
        kwargs.setdefault("title", "Navigator")
        kwargs.setdefault("background", desktop_style(scheme))
        self.manager = Manager(left, right, scheme)
        super().__init__(root=self.manager, **kwargs)

    def on_stop(self) -> None:
        # The shell would otherwise outlive the terminal it was talking to.
        self.manager.console.stop()

    def on_key(self, event: KeyEvent) -> bool:
        manager = self.manager
        panel = manager.active_panel

        if event.matches("ctrl+o"):
            manager.toggle_console()
            return True
        if manager.console_visible:
            # Everything else belongs to the program on the console -- it has
            # the screen, so it should have the keyboard.  Only the two ways
            # out and the scrollback are kept back.
            if event.matches("f10", "ctrl+q"):
                self.exit()
            elif event.matches("shift+pageup"):
                manager.console.scroll_back()
            elif event.matches("shift+pagedown"):
                manager.console.scroll_forward()
            else:
                return manager.console.send(event)
            return True

        if event.matches("f10", "ctrl+q", "alt+x"):
            self.exit()
        elif event.matches("tab"):
            manager.switch_panel()
        elif event.matches("up"):
            panel.move_cursor(-1)
        elif event.matches("down"):
            panel.move_cursor(1)
        elif event.matches("pageup"):
            panel.move_cursor(-max(1, panel.rows - 1))
        elif event.matches("pagedown"):
            panel.move_cursor(max(1, panel.rows - 1))
        elif event.matches("home"):
            panel.move_cursor(-len(panel.entries))
        elif event.matches("end"):
            panel.move_cursor(len(panel.entries))
        elif event.matches("enter"):
            panel.enter()
        elif event.matches("ctrl+r"):
            panel.reload()
        else:
            return False
        return True

    def on_mouse(self, event: MouseEvent) -> bool:
        manager = self.manager
        if manager.console_visible:
            if event.is_wheel and manager.console.contains(event.x, event.y):
                if event.button == "wheel_up":
                    manager.console.scroll_back()
                else:
                    manager.console.scroll_forward()
                return True
            return False
        for panel in (manager.left, manager.right):
            if not panel.contains(event.x, event.y):
                continue
            if not panel.active:
                manager.switch_panel()
            if event.is_wheel:
                panel.move_cursor(-3 if event.button == "wheel_up" else 3)
            elif event.action == "press" and event.button == "left":
                row = event.y - panel.y - 1
                if 0 <= row < panel.rows:
                    panel.move_cursor(panel.scroll + row - panel.cursor)
            return True
        return False


class PrintVersion(argparse.Action):
    """``--version``, printed verbatim.

    argparse's own ``version`` action runs the string through the help
    formatter, which word-wraps it to the terminal -- and the banner is mostly
    one long path, so on a narrow window it comes back broken across lines and
    cannot be copied out of a bug report.  Printing it directly is the whole
    of the difference.
    """

    def __init__(self, option_strings, dest, help=None):
        super().__init__(option_strings, dest, nargs=0, help=help)

    def __call__(self, parser, namespace, values, option_string=None):
        print(version_banner())
        parser.exit()


def version_banner() -> str:
    """What ``--version`` prints: the version, and *which copy* is running.

    The second half is the useful half.  Navigator can be installed three ways
    at once -- a system package under ``/usr/lib``, a pipx or ``pip --user``
    copy under ``~/.local``, and a checkout -- and ``~/.local/bin`` comes
    before ``/usr/bin`` on nearly every PATH, so the one that runs is often not
    the one that was just installed.  Printing the path turns that from a
    mystery into a glance, which is why ``pip --version`` has done it for
    years and why the format here follows it.

    The version itself prefers the distribution metadata over ``__version__``:
    they differ exactly when a checkout has been edited since it was
    installed, and metadata is absent precisely in the case where the source
    tree is the honest answer.
    """
    try:
        version = metadata.version("navigator-fm")
    except metadata.PackageNotFoundError:
        version = __version__
    here = Path(__file__).resolve().parent
    python = ".".join(str(n) for n in sys.version_info[:3])
    return f"nav {version} from {here} (python {python})"


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="nav", description=__doc__)
    parser.add_argument("left", nargs="?", help="the directory the left panel opens")
    parser.add_argument("right", nargs="?", help="the directory the right panel opens")
    parser.add_argument(
        "--version", action=PrintVersion,
        help="print the version, and which copy of Navigator is running",
    )
    parser.add_argument(
        "--theme", default=DEFAULT_THEME, metavar="NAME",
        help="a colour scheme from navigator/styles/themes (default: %(default)s)",
    )
    parser.add_argument(
        "--list-themes", action="store_true", help="print the theme names and exit",
    )
    parser.add_argument(
        "--palette", choices=("dos", "terminal"), default=None,
        help="what a colour name in a theme means: the VGA register value DOS "
             "Navigator asked for (default), or whatever the terminal's own "
             "scheme paints for it",
    )
    parser.add_argument(
        "--glyphs", choices=("auto", "ascii", "unicode", "nerd"), default="auto",
        help="which characters the terminal's font can draw: `ascii' for plain "
             "+-| frames, `unicode' for box drawing, `nerd' to add a Nerd Font "
             "icon beside each name (default: detect)",
    )
    parser.add_argument(
        "--reprogram-palette", action="store_true",
        help="rewrite the terminal's sixteen colour registers to the DOS "
             "palette for as long as Navigator runs -- the only thing that "
             "helps on a terminal that names no other colours",
    )
    args = parser.parse_args(sys.argv[1:] if argv is None else argv)

    if args.list_themes:
        print("\n".join(theme_names()))
        return 0
    try:
        scheme = load_scheme(args.theme)
    except LookupError as exc:
        parser.error(str(exc))

    # A theme that names its colours is transcribing a palette that left the
    # VGA registers alone, so `blue' means the value that adapter held and not
    # whatever this terminal calls blue -- which is why Navigator pins by
    # default where navkit, knowing nothing of DOS, does not.  Precedence runs
    # flag, then NAVKIT_PALETTE, then that default; `detect' handles the last
    # two, and an explicit flag is applied over its answer.
    info = TerminalInfo.detect(
        is_tty=is_a_tty(sys.stdin, sys.stdout), palette=VGA_PALETTE
    )
    if args.palette is not None:
        info = replace(
            info, palette=VGA_PALETTE if args.palette == "dos" else None
        )
    # Same three-step precedence for the character repertoire, and the same
    # reason for spelling it out: `detect' has already weighed NAVKIT_GLYPHS
    # against what it found, so the flag is applied over that answer.
    if args.glyphs != "auto":
        info = replace(info, glyphs=tier_named(args.glyphs, info.glyphs))
    terminal = Terminal(info=info, reprogram_palette=args.reprogram_palette)

    left = Path(args.left).expanduser().resolve() if args.left else Path.cwd()
    right = Path(args.right).expanduser().resolve() if args.right else left
    Navigator(left, right, scheme, terminal=terminal).run()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())